
function HomeController() {

}

app.component('home', {
    templateUrl: 'home/home.html',
    controller: HomeController,
    controllerAs: 'vm'
});