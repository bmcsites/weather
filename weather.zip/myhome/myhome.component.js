
function MyhomeController() {

}

app.component('myhome', {
    templateUrl: 'myhome/myhome.html',
    controller: MyhomeController,
    controllerAs: 'vm'
});